﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;
using System.Threading.Tasks;
using Entidades.Externa.Sellada;
using System.Data;
using Entidades;
using System.Data.SqlClient;

namespace TestEntidades
{
    public static class Extensora
    {
        public static string ObtenerDatos(this PersonaExternaSellada pers)
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("Nombre: " + pers.Nombre);
            sb.AppendLine("Apellido: " + pers.Apellido);
            sb.AppendLine("Edad: " + pers.Edad);
            sb.AppendLine("Sexo: " + pers.Sexo);

            return sb.ToString();
        }

        public static bool EsNulo(this Object obj)
        {
            return obj == null;
        }

        public static Int32 CantidadDigitos(this Int32 num)
        {
            string aux = num.ToString();
            return aux.Length;
        }

        public static bool TieneLaMismaCantidad(this Int32 num, Int32 cantDigitos)
        {
            return num.CantidadDigitos() == cantDigitos;
        }

        public static List<Persona> TraerDB(this Persona p1)
        {
            //SqlConnection conexion = new SqlConnection(Properties.Settings.Default.conexion);
        }
    }
}
