﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Entidades.Externa
{
    public class PersonaExternaHeredada : PersonaExterna
    {
        public PersonaExternaHeredada(string nombre, string apellido, int edad, ESexo sexo) : base(nombre, apellido, edad, sexo)
        {

        }

        public string Nombre
        {
            get { return base._nombre; }
        }

        public string Apellido
        {
            get { return base._apellido; }
        }

        public int Edad
        {
            get { return base._edad; }
        }

        public ESexo Sexo
        {
            get { return base._sexo; }
        }

        public string ObtenerDatos()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendLine("Nombre: " + base._nombre);
            sb.AppendLine("Apellido: " + base._apellido);
            sb.AppendLine("Edad: " + base._edad);
            sb.AppendLine("Sexo: " + base._sexo);

            return sb.ToString();
        }
    }
}
