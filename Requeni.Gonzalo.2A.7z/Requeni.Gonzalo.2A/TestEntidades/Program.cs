﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Entidades.Externa.Sellada;

namespace TestEntidades
{
    class Program
    {
        static void Main(string[] args)
        {
            PersonaExternaSellada p1 = new PersonaExternaSellada("Gonzalo", "Requeni", 21, Entidades.Externa.Sellada.ESexo.Masculino);
            
            Console.WriteLine(p1.ObtenerDatos());
            int num = 662;
            Console.WriteLine(num.CantidadDigitos());
            Console.ReadLine();
        }
    }
}
